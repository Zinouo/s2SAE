#! /usr/bin/python
# -*- coding:utf-8 -*-
from flask import Blueprint
from flask import Flask, request, render_template, redirect, url_for, abort, flash, session, g

from connexion_db import get_db

admin_commande = Blueprint('admin_commande', __name__,
                        template_folder='templates')

@admin_commande.route('/admin/commande/index')
def admin_index():
    return render_template('admin/layout_admin.html')


@admin_commande.route('/admin/commande/show', methods=['get','post'])
def admin_commande_show():
    mycursor = get_db().cursor()
    id = request.args.get('id')
    print(id)

    sql = '''select Cm.id, Cm.date_achat, L.quantite, (C.prix*L.quantite) as prix_tot, Cm.etat_id, E.libelle, Cm.user_id, U.username
                  from commande Cm
                  inner join ligne_commande L on L.commande_id =Cm.id
                  inner join chaussure C on C.idChaussure = L.chaussure_id
                  inner join etat E on E.id = Cm.etat_id
                  inner join user U on U.id = Cm.user_id       
                  ;
              '''
    mycursor.execute(sql)
    commande = mycursor.fetchall()

    if (id != None):
        sql = '''select C.nom, L.quantite, C.prix, (C.prix*L.quantite) as prix_tot
                  from chaussure C
                  inner join ligne_commande L on L.chaussure_id = C.idChaussure
                  inner join commande Cm on Cm.id = L.commande_id
                  where Cm.id = (%s)
                  ;'''
        mycursor.execute(sql, id)
        article_commande = mycursor.fetchall()
        print(article_commande)
        return render_template('admin/commandes/show.html', commande=commande, article_commande=article_commande)

    return render_template('admin/commandes/show.html', commande=commande)


@admin_commande.route('/admin/commande/valider', methods=['get' , 'post'])
def admin_commande_valider():
    mycursor = get_db().cursor()
    id = request.args.get('id')
    print("id =",id)
    sql = '''update commande set etat_id = 2 where id=%s; '''
    mycursor.execute(sql, id)
    get_db().commit()
    return redirect('/admin/commande/show')
