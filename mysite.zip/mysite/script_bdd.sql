DROP TABLE IF EXISTS couleur;
DROP TABLE IF EXISTS panier;
DROP TABLE IF EXISTS chaussure;
DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS types_chaussures;
DROP TABLE IF EXISTS panier;
DROP TABLE IF EXISTS etat;
DROP TABLE IF EXISTS commande;
DROP TABLE IF EXISTS ligne_commande;

CREATE TABLE IF NOT EXISTS types_chaussures (
    id_type             INT UNSIGNED AUTO_INCREMENT,
    libelle_type        VARCHAR(50),
    PRIMARY KEY (id_type)
);

INSERT INTO types_chaussures (libelle_type) VALUES
    ('Jordan'),
    ('Converse'),
    ('Jordan'),
    ('Nike');
SELECT * FROM types_chaussures;

CREATE TABLE IF NOT EXISTS user(
    id INT AUTO_INCREMENT,
    email VARCHAR (255),
    username VARCHAR (255),
    password VARCHAR (255),
    role VARCHAR (255),
    est_actif INT(1),
    pseudo VARCHAR (255),

    -- token_email VARCHAR(255),
    -- token_email_date DATE(),

    -- go_auth_token VARCHAR(255),
    -- go_username_token VARCHAR(255),

    PRIMARY KEY (id)
)

ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO user (id, email, username, password, role,  est_actif) VALUES
(NULL, 'admin@admin.fr', 'admin', 'sha256$pBGlZy6UukyHBFDH$2f089c1d26f2741b68c9218a68bfe2e25dbb069c27868a027dad03bcb3d7f69a', 'ROLE_admin', 1);
INSERT INTO user  (id, email, username, password, role, est_actif) VALUES
(NULL, 'client@client.fr', 'client', 'sha256$Q1HFT4TKRqnMhlTj$cf3c84ea646430c98d4877769c7c5d2cce1edd10c7eccd2c1f9d6114b74b81c4', 'ROLE_client', 1);
INSERT INTO user  (id, email, username, password, role,  est_actif) VALUES
(NULL, 'client2@client2.fr', 'client2', 'sha256$ayiON3nJITfetaS8$0e039802d6fac2222e264f5a1e2b94b347501d040d71cfa4264cad6067cf5cf3', 'ROLE_client',1);


SELECT * FROM user;


CREATE TABLE IF NOT EXISTS chaussure (
idChaussure int NOT NULL auto_increment
, nom varchar(255)
, prix INT
, image varchar(255)
, note numeric(6,2) default 3
, stock int default 10
, idTypeMeuble INT UNSIGNED
, primary key (idChaussure)
, CONSTRAINT fk_MeubleType FOREIGN KEY (idTypeMeuble) REFERENCES types_chaussures(id_type)
);



CREATE TABLE couleur (
idCouleur int auto_increment
, libelle varchar(255)
, primary key (idCouleur)
);

INSERT INTO couleur(libelle) VALUES
('rouge'),('bleu'),
('vert');


CREATE TABLE IF NOT EXISTS panier (
  idPanier int(11) NOT NULL AUTO_INCREMENT,
  user_id int,
  chaussure_id int,
  date_achat date,
  prix_unit int,
  quantite int(11),
  PRIMARY KEY (idPanier),
  CONSTRAINT FK_panierUser FOREIGN KEY (user_id) REFERENCES user(id),
  CONSTRAINT FK_panierChaussure FOREIGN KEY (chaussure_id) REFERENCES chaussure(idChaussure)
);


INSERT INTO chaussure (idChaussure,nom, prix, image) VALUES
(NULL, 'Jordan 1', 100, 'jordan1.jpg'),
(NULL, 'Converse' , 90, 'converse.jpg'),
(NULL, 'Jordan 4 Cactus jack' , 150, 'jordan4.jpg'),
(NULL, 'Air force 1 flea market' , 120, 'af1.jpg');

SELECT * FROM chaussure;

CREATE TABLE etat (
    id int(11) NOT NULL AUTO_INCREMENT,
    libelle VARCHAR(255),
    PRIMARY KEY (id)
);

INSERT INTO etat(libelle) VALUES ('en cours de traitement'), ('expédié'), ('validé');

CREATE TABLE commande (
    id int(11) NOT NULL AUTO_INCREMENT,
    date_achat datetime,
    user_id int(11),
    etat_id int (11),
    PRIMARY KEY (id),
    CONSTRAINT commande_ibfk_1 FOREIGN KEY (user_id) REFERENCES user(id),
    CONSTRAINT commande_ibfk_2 FOREIGN KEY (etat_id) REFERENCES etat(id)
);

CREATE TABLE ligne_commande (
    id int(11) NOT NULL AUTO_INCREMENT,
    commande_id int(11),
    chaussure_id int(11),
    prix INT,
    quantite int(11),
    PRIMARY KEY (id),
    CONSTRAINT ligne_commande_ibfk_1 FOREIGN KEY (commande_id) REFERENCES commande(id),
    CONSTRAINT ligne_commande_ibfk_2 FOREIGN KEY (chaussure_id) REFERENCES chaussure(idChaussure)
);

